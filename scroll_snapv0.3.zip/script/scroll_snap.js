// Scroll_snap v0.3
// 
// Beerware License
// 제작자 : 한지호(ece125@naver.com)
// 사용하시고 고마우시면 맥주나 한잔 사주세여
//
// -*-*-*-*-*-*-*-*-*-*-개    요*-*-*-*-*-*-*-*-*-*-*-
// scroll_snap은 페이지 내에서 스크롤을 하면 .snapbox라고 이름지어진
// 나열된 박스의 위치로 스크롤이 스냅 되도록 하는 스크립트입니다.
// 중복 스크롤을 막았으므로 한번에 여러번 스크롤되는 것을 막았습니다.
//
// -*-*-*-*-*-*-*-*-*-*-사용방법*-*-*-*-*-*-*-*-*-*-*-
// 1. scroll_snap.js를 html문서의 body태그의 안쪽 맨 하단에 추가하기.
// 2. html문서에서 snap이 되어야 할 박스(예> div, section, article 따위)들에게
//    snapbox라는 클래스 추가하기.
// 3. 끗.
//
// -*-*-*-*-*-*-*-*-*-*-유의사항*-*-*-*-*-*-*-*-*-*-*-
// body의 자식 태그들에게 클래스 snapbox를 지정하십시오.
// body의 자식 snapbox 이외의 다른 형제태그를 두지 마십시오.
// 
// 

$(document).ready(function(){
    
    // -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    
    // 설정값
    var threshold = 800; // 재 스크롤 허용 시간
    var speed = 800; // 스크롤 속도
    // 주의사항 : 항상 threshold는 speed 보다 같거나 커야 한다.
    
    // -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
    
    
    
    
    
    
    var boxlen = $(".snapbox").length;
    var boxoffset = [];
    var current = 0;
    
    // 각 .snapbox들의 Y위치 측정
    for(i=0; i<boxlen; i++){
        boxoffset[i] = Math.floor($(".snapbox").eq(i).offset().top);
    }
    
    // 현재 snapbox의 번호 추출
    function rechk(){
        var scr = $(window).scrollTop();
        scr = Math.floor(scr);
        
        for(i=0; i<boxlen; i++){
            if(i >= boxlen-1){
                if(scr >= boxoffset[i] && scr < $(document).height()){
                    current = i;
                }
            }else{
                if(scr >= boxoffset[i] && scr < boxoffset[i+1]){
                    current = i;
                }
            }
        }
        $("#demo").text(current);
    }
    
    
    
    
    var keys = {37: 1, 38: 1, 39: 1, 40: 1};

    function preventDefault(e) {
      e = e || window.event;
      if (e.preventDefault)
          e.preventDefault();
      e.returnValue = false;  
        console.API.clear();
    }

    function preventDefaultForScrollKeys(e) {
        if (keys[e.keyCode]) {
            preventDefault(e);
            return false;
        }
    }

    function disableScroll() {
      if (document.querySelectorAll("*").addEventListener) // older FF
          document.querySelectorAll("*").addEventListener('DOMMouseScroll', preventDefault, false);
      document.querySelectorAll("*").onwheel = preventDefault; // modern standard
      document.querySelectorAll("*").onmousewheel = document.onmousewheel = preventDefault; // older browsers, IE
      document.querySelectorAll("*").ontouchmove  = preventDefault; // mobile
      document.onkeydown  = preventDefaultForScrollKeys;
    }

    function enableScroll() {
        if (document.querySelectorAll("*").removeEventListener)
            document.querySelectorAll("*").removeEventListener('DOMMouseScroll', preventDefault, false);
        document.querySelectorAll("*").onmousewheel = document.onmousewheel = null; 
        document.querySelectorAll("*").onwheel = null; 
        document.querySelectorAll("*").ontouchmove = null;  
        document.onkeydown = null;  
    }
    
    
    
    
    
    
    // 중복 스크롤 실행 방지 스위치
    var timer = true;
    
    // 스크롤(스와이프) 시작 되었을때
    $("*").on('scroll touchmove mousewheel DOMMouseScroll', function(e){
        e = e || window.event;
        // 현재 스크롤 위치 포인터
        var curscr = $(window).scrollTop() + $(window).height();
        var limit;
        if(boxoffset[current+1] != undefined){
            // 마지막 박스가 아닐때
            limit = boxoffset[current+1];
        }else{
            // 마지막 박스일때
            limit = $(document).height();
        }
        if(curscr < limit && curscr >= boxoffset[current]){
            // 박스 내부에서 스크롤중일때
            if(timer || !$("head,body").is(":animated")){
                // 애니메이션이 작동중이지 않을때는 스크롤 허용
                enableScroll();
            }
            if(!timer || $("head,body").is(":animated")){
                // 애니메이션이 작동중일때는 스크롤 금지
                disableScroll();
            }
        }else{
            // 박스 경계선에서 스크롤중일때
            if(timer){
                // 중복스크롤 실행 방지 스위치 잠깐 켜고
                timer = false;
                var delta;
                if(event.wheelDelta){
                    delta = event.wheelDelta;
                }else{
                    delta = -1 * event.deltaY;
                }
                // 스크롤 올렸을때
                if(delta > 0) {
                    if(boxoffset[current - 1] != undefined){
                        $("html,body").stop().animate({
                            scrollTop: boxoffset[current] + "px"
                        },{
                            duration: speed,
                            start: function(now,fx){
                                disableScroll();
                            },
                            complete: function(){
                                timer = true;
                            }
                        });
                    }else{
                        $("html,body").stop().animate({
                            scrollTop: "0px"
                        },{
                            duration: speed,
                            start: function(now,fx){
                                disableScroll();
                            },
                            complete: function(){
                                timer = true;
                            }
                        });
                    }
                }
                // 스크롤 내렸을때
                else{
                    if(boxoffset[current + 1] != undefined){
                        $("html,body").stop().animate({
                            scrollTop: boxoffset[current + 1] + "px"
                        },{
                            duration: speed,
                            start: function(now,fx){
                                disableScroll();
                            },
                            complete: function(){
                                timer = true;
                            }
                        });
                    }
                }
                // 제한시간 후에 스위치 끄기
                setTimeout(function(){
                    timer = true;
                },threshold);
                // 기본 사용자 스크롤 금지하기
                disableScroll();
            }
        }
    });
    
    
    rechk();
    $(window).scroll(function(){
        rechk();
    });
    $(window).resize(function(){
        rechk();
    });
    
    
    
    if (typeof console._commandLineAPI !== 'undefined') {
        console.API = console._commandLineAPI;
    } else if (typeof console._inspectorCommandLineAPI !== 'undefined') {
        console.API = console._inspectorCommandLineAPI;
    } else if (typeof console.clear !== 'undefined') {
        console.API = console;
    }

    console.API.clear();
    
    
});







